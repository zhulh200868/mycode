/* Compile with "gcc -o weirdness weirdness.c" */
#include <stdio.h>

int main(void)
{
        fprintf(stderr, "Blorp.\n");
}
