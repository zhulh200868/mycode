.. _license:

License
=======

XlsxWriter is released under a BSD license.


.. include:: ../../../LICENSE.txt
