.. _ex_hello_world:

Example: Hello World
====================

The simplest possible spreadsheet. This is a good place to start to see if
the XlsxWriter module is installed correctly.

.. image:: _images/hello01.png

.. literalinclude:: ../../../examples/hello_world.py
