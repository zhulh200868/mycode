.. _ex_chart_pattern:

Example: Chart with Pattern Fills
=================================

Example of creating an Excel chart with pattern fills, in the columns.

.. image:: _images/chart_pattern.png
   :scale: 75 %

.. literalinclude:: ../../../examples/chart_pattern.py
